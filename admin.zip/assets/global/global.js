// Search Modal
const search = document.querySelector("#search");
const searchBar = document.querySelector("#search-bar");


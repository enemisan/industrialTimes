<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN" "http://www.w3.org/TR/REC-html40/loose.dtd">
<html>

<body>
    <div id="content" class="content-div">


        <a class="t-column-flex" href="news/_cloud_computing.php" target="_blank"><h1>MTN Group Investing $320m on new fiber cables To Speed up Video Streaming, Cloud computing in 10 African Countries</h1><div><img src="news/assets/images/blog-image_19.jpg" alt="MTN Group Investing $320m on new fiber cables To Speed up Video Streaming, Cloud computing in 10 African Countries"></div></a><a class="t-column-flex" href="news/_herbert_wigwe.php" target="_blank"><h1>Access Bank's Wigwe Becomes President of France -  Nigeria Business Council</h1><div><img src="news/assets/images/blog-image_20.jpg" alt="Access Bank's Wigwe Becomes President of France -  Nigeria Business Council"></div></a><a class="t-column-flex" href="news/textile_industry.php" target="_blank"><h1>Textile Industry Emits 1.2bn tons of carbon emissions annually</h1><div><img src="news/assets/images/blog-image_21.jpg" alt="Textile Industry Emits 1.2bn tons of carbon emissions annually"></div></a><a class="t-column-flex" href="news/_dimitris_kostianis.php" target="_blank"><h1>PZ Cussons Nigeria: Dimitris Kostianis Becomes CEO From June 1</h1><div><img src="news/assets/images/blog-image_25.jpg" alt="PZ Cussons Nigeria: Dimitris Kostianis Becomes CEO From June 1"></div></a></div>
</body>

</html>
